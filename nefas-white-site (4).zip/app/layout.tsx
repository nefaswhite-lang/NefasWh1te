export const metadata = { title: 'Nefas White — MENA Wholesale', description: 'All-White Snus — B2B' }
import './globals.css'
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (<html lang="en"><body>{children}</body></html>);
}